﻿using BookProject2.Model.Classes;
using BookProject2.Model.Enum;
using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace BookProject2
{
    public sealed partial class AddBooks : Page
    {
        public ClassManager ClassManager { get; set; }
        public object ComboItem { get; set; }
        public Category Category { get; set; } = Category.None;

        public AddBooks()
        {
            InitializeComponent();
        }

        private void MyCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboItem = ((ComboBoxItem)((ComboBox)sender).SelectedItem).Content;
            switch (ComboItem.ToString())
            {
                case "Child":
                    Category = Category.Child;
                    break;

                case "Art And Design":
                    Category = Category.ArtAndDesign;
                    break;

                case "Fiction":
                    Category = Category.Fiction;
                    break;
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            ClassManager = (ClassManager)e.Parameter;
        }

        private async void AddBookNow_Click(object sender, RoutedEventArgs e)
        {
            Tuple<Category, string, string> bundleForNewBook = Tuple.Create(Category, NameOfAuthor.Text, NameOfBook.Text);
            if (Category != Category.None)
            {
                ClassManager.AddNewBook(bundleForNewBook);
                NavigateThePageThatBookWasAdded(bundleForNewBook);
            }
            else
            {
                var noWifiDialog = new ContentDialog()
                {
                    Title = "Category isn't defined",
                    Content = "Please select Category.",
                    CloseButtonText = "OK"
                };

                _ = await noWifiDialog.ShowAsync();
            }
        }

        private void NavigateThePageThatBookWasAdded(Tuple<Category, string, string> bundleForNewBook)
        {
            switch (bundleForNewBook.Item1)
            {
                case Category.Child:
                    GoToPage(typeof(ChildPage));
                    break;

                case Category.Fiction:
                    GoToPage(typeof(FictionPage));
                    break;

                case Category.ArtAndDesign:
                    GoToPage(typeof(ArtAndDesignPage));
                    break;
            }
        }

        public void GoToPage(Type sourcePageType) =>
            _ = Frame.Navigate(sourcePageType, ClassManager);
    }
}