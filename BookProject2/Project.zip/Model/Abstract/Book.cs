﻿using BookProject2.Model.Enum;
using System;
using System.Collections.Generic;

namespace BookProject2.Model.Abstract
{
    public abstract class Book
    {
        public Category Category { get; private set; }
        public Dictionary<string, Book> privateBookDictionary { get; set; }
        public string DefultBookImage { get; private set; } = "BookImages/book.png";

        private int page;
        private string nameOfBook;
        private string nameOfAuthor;
        private string imageOfBook;

        private const string DefultAuthorName = "Unknown Author";
        private const string DefultBookName = "Unknown Book Name";

        public string ImageOfBook
        {
            get { return imageOfBook; }
            set
            {
                if (!(string.IsNullOrWhiteSpace(value) || string.IsNullOrEmpty(value)))
                    imageOfBook = value;
            }
        }

        public int Page
        {
            get => page;
            set
            {
                if (!(value < 0) && !(value > 2000))
                    page = value;
            }
        }

        public string NameOfBook
        {
            get => nameOfBook;
            set
            {
                if (!(string.IsNullOrWhiteSpace(value) || string.IsNullOrEmpty(value)))
                    nameOfBook = value;
                else
                    NameOfBook = DefultBookName;
            }
        }

        public string NameOfAuthor
        {
            get => nameOfAuthor;
            set
            {
                if (!(string.IsNullOrWhiteSpace(value) || string.IsNullOrEmpty(value)))
                    nameOfAuthor = value;
                else
                    NameOfAuthor = DefultAuthorName;
            }
        }

        public Book()
        {
        }

        public Book(Category category, string nameOfAotor, string nameOfBook)
        {
            NameOfAuthor = nameOfAotor;
            NameOfBook = nameOfBook;
            Category = category;
        }

        public Book(Category category, string nameOfAotor, string nameOfBook, string imageUri)
            : this(category, nameOfAotor, nameOfBook)
        {
            ImageOfBook = imageUri;
        }

        public Book(Category category, string nameOfAotor, string nameOfBook, string imageUri, int pages)
            : this(category, nameOfAotor, nameOfBook, imageUri)
        {
            Page = pages;
        }

        public abstract Book AddNewBook(Tuple<Category, string, string> person);

        public abstract void GetBooks();
    }
}