﻿using BookProject2.Model.Abstract;

using System.Collections.ObjectModel;

namespace BookProject2.Model.Interface
{
    internal interface IBookCollection
    {
        ObservableCollection<Book> privateObservableCollectionOfBook { get; set; }
    }
}