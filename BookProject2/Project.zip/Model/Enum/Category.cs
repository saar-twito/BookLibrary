﻿namespace BookProject2.Model.Enum
{
    public enum Category : byte
    {
        None,
        Child,
        Fiction,
        ArtAndDesign,
    }
}