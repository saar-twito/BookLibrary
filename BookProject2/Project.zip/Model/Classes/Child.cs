﻿using BookProject2.Model.Abstract;
using BookProject2.Model.Enum;
using BookProject2.Model.Interface;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace BookProject2.Model.Classes
{
    public class Child : Book, IBookCollection
    {
        public ClassManager ClassManager { get; private set; }
        public ObservableCollection<Book> privateObservableCollectionOfBook { get; set; }

        public Child(ClassManager classManager)
        {
            ClassManager = classManager;

            GetBooks();
        }

        public Child(Category category, string nameOfAotor, string nameOfBook) : base(category, nameOfAotor, nameOfBook)
        {
        }

        public Child(Category category, string nameOfAotor, string nameOfBook, string imageUri) : base(category, nameOfAotor, nameOfBook, imageUri)
        {
        }

        public Child(Category category, string nameOfAotor, string nameOfBook, string imageUri, int pages) : base(category, nameOfAotor, nameOfBook, imageUri, pages)
        {
        }

        public override void GetBooks()
        {
            var child1 = new Child(Category.Child, "A", "Hello Kitty's Fabulous Things", "BookImages/Child/Hello Kitty's Fabulous Things.png");
            var child2 = new Child(Category.Child, "B", "My First Hebrew Word Book", "BookImages/Child/My First Hebrew Word Book.png", pages: 56);
            var child3 = new Child(Category.Child, "C", "Sammy Spider's First Mitzvah", "BookImages/Child/Sammy Spider's First Mitzvah.png");
            var child4 = new Child(Category.Child, "D", "The Giving Tree", "BookImages/Child/The Giving Tree.png", pages: 985);
            var child5 = new Child(Category.Child, "E", "The Recruit", "BookImages/Child/The Recruit.png", pages: 120);

            // UI
            privateObservableCollectionOfBook = new ObservableCollection<Book>
            {
                child1,
                child2,
                child3,
                child4,
                child5,
            };

            // Search
            Task a = Task.Run(() =>
            {
                ClassManager.GlobalDictionary.Add(child1.NameOfBook, child1);
                ClassManager.GlobalDictionary.Add(child2.NameOfBook, child2);
                ClassManager.GlobalDictionary.Add(child3.NameOfBook, child3);
                ClassManager.GlobalDictionary.Add(child4.NameOfBook, child4);
                ClassManager.GlobalDictionary.Add(child5.NameOfBook, child5);
            });

            // Privet Search
            Task b = Task.Run(() =>
            {
                privateBookDictionary = new Dictionary<string, Book>
                {
                    { child1.NameOfBook, child1 },
                    { child2.NameOfBook, child2 },
                    { child3.NameOfBook, child3 },
                    { child4.NameOfBook, child4 },
                    { child5.NameOfBook, child5 }
                };
            });

            Task.WaitAll(a, b);
        }

        public override Book AddNewBook(Tuple<Category, string, string> bundleForNewBook)
        {
            Child child = new Child(bundleForNewBook.Item1, bundleForNewBook.Item2, bundleForNewBook.Item3, DefultBookImage);
            privateObservableCollectionOfBook.Add(child);

            return child;
        }
    }
}