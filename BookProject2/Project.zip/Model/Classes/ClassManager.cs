﻿using BookProject2.Model.Abstract;
using BookProject2.Model.Enum;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace BookProject2.Model.Classes
{
    public class ClassManager
    {
        public Dictionary<string, Book> GlobalDictionary { get; set; }
        public ArtAndDesign ArtAndDesign { get; private set; }
        public Child Child { get; private set; }
        public Fiction Fiction { get; private set; }
        public Category Category { get; private set; }
        public Book MyBook { get; set; }

        public ClassManager()
        {
            GlobalDictionary = new Dictionary<string, Book>();
            ArtAndDesign = new ArtAndDesign(this);
            Fiction = new Fiction(this);
            Child = new Child(this);
        }

        internal void AddNewBook(Tuple<Category, string, string> bundleForNewBook)
        {
            switch (bundleForNewBook.Item1)
            {
                case Category.Child:
                    IsNameExsist(Child, bundleForNewBook);
                    break;

                case Category.Fiction:
                    IsNameExsist(Fiction, bundleForNewBook);
                    break;

                case Category.ArtAndDesign:
                    IsNameExsist(ArtAndDesign, bundleForNewBook);
                    break;
            }
        }

        public void IsNameExsist(Book book, Tuple<Category, string, string> bundleForNewBook)
        {
            if (!book.privateBookDictionary.ContainsKey(bundleForNewBook.Item3))
                AddBookToGlobalDictionary(book.AddNewBook(bundleForNewBook));
        }

        public void AddBookToGlobalDictionary(Book newBook) =>
            GlobalDictionary.Add(newBook.NameOfBook, newBook);
    }
}