﻿using BookProject2.Model.Abstract;
using BookProject2.Model.Classes;
using BookProject2.Model.Enum;
using BookProject2.Model.Interface;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace BookProject2.Model
{
    public class ArtAndDesign : Book, IBookCollection
    {
        public ClassManager ClassManager { get; private set; }

        public ObservableCollection<Book> privateObservableCollectionOfBook { get; set; }

        public ArtAndDesign(ClassManager classManager)
        {
            ClassManager = classManager;
            GetBooks();
        }

        public ArtAndDesign(Category category, string nameOfAotor, string nameOfBook) : base(category, nameOfAotor, nameOfBook)
        {
        }

        public ArtAndDesign(Category category, string nameOfAotor, string nameOfBook, string imageUri)
            : base(category, nameOfAotor, nameOfBook, imageUri)
        {
        }

        public ArtAndDesign(Category category, string nameOfAotor, string nameOfBook, string imageUri, int pages)
            : base(category, nameOfAotor, nameOfBook, imageUri, pages)
        {
        }

        public override void GetBooks()
        {
            var artAndDesign1 = new ArtAndDesign(Category.ArtAndDesign, "Saar", "100 Interiors Around the World", "BookImages/Art And Design/100 Interiors Around the World.png");
            var artAndDesign2 = new ArtAndDesign(Category.ArtAndDesign, "Novin", "20th Century Photography", "BookImages/Art And Design/20th Century Photography.png", pages: 56);
            var artAndDesign3 = new ArtAndDesign(Category.ArtAndDesign, "Ofri", "Masterpieces of British Design", "BookImages/Art And Design/Masterpieces of British Design.png");
            var artAndDesign4 = new ArtAndDesign(Category.ArtAndDesign, "Lenny", "Missoni Art Colour", "BookImages/Art And Design/Missoni Art Colour.png", pages: 985);
            var artAndDesign5 = new ArtAndDesign(Category.ArtAndDesign, "Lenny", "Movies Of The 2000'S", "BookImages/Art And Design/Movies Of The 2000'S.png", pages: 985);

            // UI
            privateObservableCollectionOfBook = new ObservableCollection<Book>
            {
                artAndDesign1,
                artAndDesign2,
                artAndDesign3,
                artAndDesign4,
                artAndDesign5
            };

            // Search

            Task a = Task.Run(() =>
            {
                ClassManager.GlobalDictionary.Add(artAndDesign1.NameOfBook, artAndDesign1);
                ClassManager.GlobalDictionary.Add(artAndDesign2.NameOfBook, artAndDesign2);
                ClassManager.GlobalDictionary.Add(artAndDesign3.NameOfBook, artAndDesign3);
                ClassManager.GlobalDictionary.Add(artAndDesign4.NameOfBook, artAndDesign4);
                ClassManager.GlobalDictionary.Add(artAndDesign5.NameOfBook, artAndDesign5);
            });

            // Privet Search
            Task b = Task.Run(() =>
            {
                privateBookDictionary = new Dictionary<string, Book>
                {
                    { artAndDesign1.NameOfBook, artAndDesign1 },
                    { artAndDesign2.NameOfBook, artAndDesign2 },
                    { artAndDesign3.NameOfBook, artAndDesign3 },
                    { artAndDesign4.NameOfBook, artAndDesign4 },
                    { artAndDesign5.NameOfBook, artAndDesign5 }
                };
            });

            Task.WaitAll(a, b);
        }

        public override Book AddNewBook(Tuple<Category, string, string> bundleForNewBook)
        {
            var artAndDesign = new ArtAndDesign(bundleForNewBook.Item1, bundleForNewBook.Item2, bundleForNewBook.Item3, DefultBookImage);
            privateBookDictionary.Add(artAndDesign.NameOfBook, artAndDesign);
            privateObservableCollectionOfBook.Add(artAndDesign);

            return artAndDesign;
        }
    }
}