﻿using BookProject2.Model.Abstract;
using BookProject2.Model.Enum;
using BookProject2.Model.Interface;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace BookProject2.Model.Classes
{
    public class Fiction : Book, IBookCollection
    {
        public ClassManager ClassManager { get; private set; }
        public ObservableCollection<Book> privateObservableCollectionOfBook { get; set; }

        public Fiction(ClassManager classManager)
        {
            ClassManager = classManager;
            GetBooks();
        }

        public Fiction(Category category, string nameOfAotor, string nameOfBook) : base(category, nameOfAotor, nameOfBook)
        {
        }

        public Fiction(Category category, string nameOfAotor, string nameOfBook, string imageUri) : base(category, nameOfAotor, nameOfBook, imageUri)
        {
        }

        public Fiction(Category category, string nameOfAotor, string nameOfBook, string imageUri, int pages) : base(category, nameOfAotor, nameOfBook, imageUri, pages)
        {
        }

        public override void GetBooks()
        {
            var fiction1 = new Fiction(Category.Fiction, null, nameOfBook: "Captivated by You", imageUri: "BookImages/Fiction/Captivated by You.png", pages: 100);
            var fiction2 = new Fiction(Category.Fiction, "Chen", "Complete Dead Sea Scrolls", "BookImages/Fiction/Complete Dead Sea Scrolls.png", 56);
            var fiction3 = new Fiction(Category.Fiction, "Sandra", "Entwined With You", "BookImages/Fiction/Entwined With You.png", 23);
            var fiction4 = new Fiction(Category.Fiction, "Roy", "Gretel and the Dark", "BookImages/Fiction/Gretel and the Dark.png", 985);
            var fiction5 = new Fiction(Category.Fiction, "Roy", "The Unfinished Symphony of You and Me", "BookImages/Fiction/The Unfinished Symphony of You and Me.png", 985);

            // UI
            privateObservableCollectionOfBook = new ObservableCollection<Book>
            {
                fiction1,
                fiction2,
                fiction3,
                fiction4,
                fiction5
            };

            // Global Search
            Task a = Task.Run(() =>
            {
                ClassManager.GlobalDictionary.Add(fiction1.NameOfBook, fiction1);
                ClassManager.GlobalDictionary.Add(fiction2.NameOfBook, fiction2);
                ClassManager.GlobalDictionary.Add(fiction3.NameOfBook, fiction3);
                ClassManager.GlobalDictionary.Add(fiction4.NameOfBook, fiction4);
                ClassManager.GlobalDictionary.Add(fiction5.NameOfBook, fiction5);
            });

            // Privet Search
            Task b = Task.Run(() =>
            {
                privateBookDictionary = new Dictionary<string, Book>
                {
                    { fiction1.NameOfBook, fiction1 },
                    { fiction2.NameOfBook, fiction2 },
                    { fiction3.NameOfBook, fiction3 },
                    { fiction4.NameOfBook, fiction4 },
                    { fiction5.NameOfBook, fiction5 }
                };
            });

            Task.WaitAll(a, b);
        }

        public override Book AddNewBook(Tuple<Category, string, string> bundleForNewBook)
        {
            Fiction fiction = new Fiction(bundleForNewBook.Item1, bundleForNewBook.Item2, bundleForNewBook.Item3, DefultBookImage);
            privateObservableCollectionOfBook.Add(fiction);

            return fiction;
        }
    }
}