﻿using BookProject2.Model.Classes;
using BookProject2.Model.Enum;
using System;
using System.Linq;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace BookProject2
{
    public sealed partial class MainPage : Page
    {
        public ClassManager ClassManager { get; private set; }

        public MainPage()
        {
            InitializeComponent();

            ClassManager = new ClassManager();
            GoToPage(typeof(HomePage));
        }

        private void SearchAutoSuggestBox_TextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args) =>
            FilterBooks();

        private void SearchAutoSuggestBox_QuerySubmitted(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            if (IsEmpty(sender, args))
                if (IsItemExistentInGlobalDictionary(args))
                {
                    ClassManager.MyBook = ClassManager.GlobalDictionary[args.ChosenSuggestion.ToString()];

                    switch (ClassManager.MyBook.Category)
                    {
                        case Category.Child:
                            GoToPage(typeof(ChildPage));
                            ClearSearchBox();
                            break;

                        case Category.Fiction:
                            GoToPage(typeof(FictionPage));
                            ClearSearchBox();
                            break;

                        case Category.ArtAndDesign:
                            GoToPage(typeof(ArtAndDesignPage));
                            ClearSearchBox();
                            break;
                    }
                }
        }

        private void HamburgerButton_Click(object sender, RoutedEventArgs e) =>
            MySplitView.IsPaneOpen = !MySplitView.IsPaneOpen;

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (((ListBoxItem)(sender as ListBox).SelectedItem).Name)
            {
                case "ArtAndDesign":
                    GoToPage(typeof(ArtAndDesignPage));
                    break;

                case "Children":
                    GoToPage(typeof(ChildPage));
                    break;

                case "Fiction":
                    GoToPage(typeof(FictionPage));
                    break;

                case "Home":
                    GoToPage(typeof(HomePage));
                    break;

                case "AddBooks":
                    GoToPage(typeof(AddBooks));
                    break;
            }
        }

        private bool IsItemExistentInGlobalDictionary(AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            return ClassManager.GlobalDictionary.ContainsKey(args.ChosenSuggestion.ToString());
        }

        private void GoToPage(Type sourcePageType) =>
            _ = MyFrame.Navigate(sourcePageType, ClassManager);

        private bool IsEmpty(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            return !(sender is null && args.ChosenSuggestion is null) && SearchAutoSuggestBox.Text != string.Empty;
        }

        private void ClearSearchBox() =>
            SearchAutoSuggestBox.Text = string.Empty;

        private void FilterBooks()
        {
            SearchAutoSuggestBox.ItemsSource = ClassManager.GlobalDictionary.Keys.Where
           (p => p.Contains(SearchAutoSuggestBox.Text, StringComparison.OrdinalIgnoreCase));
        }
    }
}