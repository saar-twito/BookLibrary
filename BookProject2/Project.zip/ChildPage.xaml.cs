﻿using BookProject2.Model.Classes;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace BookProject2
{
    public sealed partial class ChildPage : Page
    {
        public ClassManager ClassManager { get; set; }

        public ChildPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            ClassManager = (ClassManager)e.Parameter;
            MyGridView.SelectedItem = ClassManager.MyBook;
        }

        private void MyGridView_ItemClick(object sender, ItemClickEventArgs e)
        {
        }
    }
}